# flask_s3_uploads/config.py

import os

S3_BUCKET                 = os.environ.get("upload-bundler-aws")
S3_KEY                    = os.environ.get("AKIATMGB4WODMOAH6JME")
S3_SECRET                 = os.environ.get("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")
S3_LOCATION               = 'http://{}.s3.amazonaws.com/'.format(upload-bundler-aws)

SECRET_KEY                = os.urandom(32)
DEBUG                     = True
PORT                      = 5000

